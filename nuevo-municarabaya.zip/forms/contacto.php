<?php
    $destino = "amcsoria@gmail.com";
    $nombre = $_POST["nombre"];
    $correo = $_POST["correo"];
    $telefono = $_POST["telefono"];
    $mensaje = $_POST["mensaje"];
    
    $contenido = "Nombre: " . $nombre . "\nCorreo: ". $correo . "\nTeléfono: ". $telefono . "\nMensaje: ".$mensaje;

    $success = mail($destino,"Contacto - Pagina Web MPC",$contenido);
    if(!$success){
        $errorMessage = error_get_last()['message'];
    }else{
        echo "<script>swal('Correo enviado exitosamente','success')</script>";
        echo "<script>setTimeout(\"location.href='index.php'\",1000)</script>";
    }

    
    //Al momento de presionar el boton ENVIAR me reenvia a la misma página
    //header("Location:index.php")
    //<?php require("index.php")


 ?>
